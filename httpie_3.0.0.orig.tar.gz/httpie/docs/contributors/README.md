Here we maintain a database of contributors, from which we generate credits on release blog posts and social media.

For the HTTPie blog see: <https://httpie.io/blog>.
