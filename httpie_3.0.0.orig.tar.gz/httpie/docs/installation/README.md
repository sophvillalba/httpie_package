Here we maintain a database of installation methods, from which we generate
the installation section in docs. If you’d like add or update an installation method,
edit [methods.yml](./methods.yml), do not edit the main docs directly.

For HTTPie installation instructions see: <https://httpie.io/docs#installation>.
