"""
HTTPie: modern, user-friendly command-line HTTP client for the API era.

"""

__version__ = '3.2.4'
__date__ = '2024-11-01'
__author__ = 'Jakub Roztocil'
__licence__ = 'BSD'
