# Represents the packaging method. This file should
# be overridden by every build system we support on
# the packaging step.

BUILD_CHANNEL = 'unknown'
