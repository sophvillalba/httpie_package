---
name: Other
about: Anything else that isn't a feature or a bug
title: ''
labels: "new"
assignees: ''

---

If you have a general question, please consider asking on Discord: https://httpie.io/chat
