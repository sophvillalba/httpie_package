---
name: Feature request
about: Suggest an enhancement for HTTPie
title: ''
labels: "new, enhancement"
assignees: ''

---

## Checklist

- [ ] I've searched for similar feature requests.

---

## Enhancement request

…

---

## Problem it solves

E.g. “I'm always frustrated when […]”, “I’m trying to do […] so that […]”.

---

## Additional information, screenshots, or code examples

…
